<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-md-12" align="center" style="margin-top:-12px;">
                        <h5 style="color:#000; background-color:#FFCC00; width:15%; min-height:25px; padding-top:5px;" align="center"><span class="fa fa-user"></span> <strong>Master Dashboard</strong></h5>
                    </div>


                    <div class="col-md-12" style="margin-bottom:-5px;" align="center">
                        <!-- <a href="{{route('area_master-index')}}"><button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>Area Master</button></a> -->
                        <a href="{{route('state-index')}}"><button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>State</button></a>
                        <a href="{{route('distric-index')}}"> <button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>District</button></a>
                        <a href="{{route('tehsil-index')}}"><button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>Tehsil</button></a>
                        <a href="{{route('city-index')}}"> <button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>City</button></a>
                        <a href="{{route('region-index')}}"> <button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>Region</button></a>
                        <a href="{{route('role_master-index')}}"> <button type="button" class="btn active" style="background-color:#0f903f; color:#FFFFFF"><i class="fa fa-list"></i>Role</button></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>