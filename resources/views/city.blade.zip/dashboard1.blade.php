@extends('layout')

@section('content')

<div>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial;
        }

        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
    <div class="row">
        <div class="col-md-12" style="margin-top:5px;">

            <div class="panel panel-default">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center"><i class="fa fa-edit"></i> &nbsp;Employee</h5>

                </div>
                <div class="col-md-2"></div>

                <div class="panel-body" style="margin-top:-10px; margin-bottom:-5px;">
                    <div class="form-group">
                        <form role="form" method="get" action="">
                            @csrf
                            <div class="col-md-12">
                                <div class="form-group" style="margin-top:-10px;">
                                    <div class="col-md-3" style="margin-top:15px;"></div>


                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>State<font color="#FF0000">*</font></label>

                                        <select class="form-control select " data-live-search="true" name="">

                                            <option value="">Select</option>


                                        </select>
                                    </div>
                                    <div class="col-md-2" style="margin-top:15px;">
                                        <label>Employee<font color="#FF0000">*</font></label>
                                        <select class="form-control select" data-live-search="true" name="" multiple="">
                                            <option value="">Select</option>

                                        </select>
                                    </div>


                                    <div class="col-md-2" style="margin-top:4.7vh;" align="left">

                                        <div class="input-group" style=" margin-bottom:15px;">

                                            <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span> Submit </button>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="col-md-2"></div>
    <div class="col-md-8">
        <div class="tab" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center">
            <button class="tablinks" onclick="openCity(event, 'Tracking')">Tracking</button>
            <button class="tablinks" onclick="openCity(event, 'Documents')">Documents</button>
            <button class="tablinks" onclick="openCity(event, 'Leave')">Leave</button>
            <button class="tablinks" onclick="openCity(event, 'Visit')">Visit</button>
        </div>
    </div>
    <div id="Tracking" class="tabcontent">

        <div>
            <div class="row">
                <div class="col-md-12" style="margin-top:5px;">

                    <div class="panel panel-default">
                        <div class="col-md-2"></div>
                        <div class="panel-body" style="margin-top:-10px; margin-bottom:-5px;">
                            <div class="form-group">
                                <form role="form" method="get" action="">
                                    @csrf
                                    <div class="col-md-12">
                                        <div class="form-group" style="margin-top:-10px;">
                                            <div class="col-md-3" style="margin-top:15px;"></div>


                                            <div class="col-md-2" style="margin-top:15px;">
                                                <label>From Date<font color="#FF0000">*</font></label>
                                                <input type="date" placeholder=" " class="form-control" required/ name="from_date">
                                            </div>
                                            <div class="col-md-2" style="margin-top:15px;">
                                                <label>To Date<font color="#FF0000">*</font></label>
                                                <input type="date" placeholder=" " class="form-control" required/ name="to_date">
                                            </div>


                                            <div class="col-md-2" style="margin-top:4.7vh;" align="left">

                                                <div class="input-group" style=" margin-bottom:15px;">

                                                    <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span> Submit </button>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div>
                <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-10">
                        <div class="panel panel-default">
                            <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center"><i class="fa fa-edit"></i> Tracking </h5>

                            <div class="panel-body">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Time</th>
                                            <th>KiloMeter</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <a href="">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete "><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
    </div>

    <div id="Documents" class="tabcontent">

        <div>
            <div>

                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8" style="margin-top: 10px;">
                        <div class="panel panel-default">
                            <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center"><i class="fa fa-edit"></i> Documents </h5>

                            <div class="panel-body">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Applied</th>
                                            <th>Experience Certificate</th>
                                            <th>Status</th>
                                            <th>Approval</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <a href="">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete "><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
    </div>

    <div id="Leave" class="tabcontent">

        <div>
            <div>
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8" style="margin-top: 10px;">
                        <div class="panel panel-default">
                            <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center">
                                <i class="fa fa-edit"></i> Leave
                            </h5>

                            <div class="panel-body">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Time</th>
                                            <th>Report</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <a href="">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete "><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
    </div>

    <div id="Visit" class="tabcontent">

        <div>

            <div class="row">
                <div class="col-md-12" style="margin-top:5px;">

                    <div class="panel panel-default">
                        <div class="col-md-2"></div>
                        <div class="panel-body" style="margin-top:-10px; margin-bottom:-5px;">
                            <div class="form-group">
                                <form role="form" method="get" action="">
                                    @csrf
                                    <div class="col-md-12">
                                        <div class="form-group" style="margin-top:-10px;">
                                            <div class="col-md-3" style="margin-top:15px;"></div>


                                            <div class="col-md-2" style="margin-top:15px;">
                                                <label>From Date<font color="#FF0000">*</font></label>
                                                <input type="date" placeholder=" " class="form-control" required/ name="from_date">
                                            </div>
                                            <div class="col-md-2" style="margin-top:15px;">
                                                <label>To Date<font color="#FF0000">*</font></label>
                                                <input type="date" placeholder=" " class="form-control" required/ name="to_date">
                                            </div>


                                            <div class="col-md-2" style="margin-top:4.7vh;" align="left">

                                                <div class="input-group" style=" margin-bottom:15px;">

                                                    <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span> Submit </button>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div>


                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8" style="margin-top: 10px;">
                        <div class="panel panel-default">
                            <h5 class="panel-title" style="color:#FFFFFF; background-color:#0f903f; width:100%; font-size:14px;" align="center">
                                <i class="fa fa-edit"></i> Visit
                            </h5>

                            <div class="panel-body">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Time</th>
                                            <th>Report</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>
                                                <a href="">
                                                    <button style="background-color:#ff0000; border:none; max-height:25px; margin-top:-5px; margin-bottom:-5px;" type="button" class="btn btn-info" data-toggle="tooltip" data-placement="top" title="Delete "><i class="fa fa-trash-o" style="margin-left:5px;"></i></button>
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
    </div>

    @stop


    @section('js')

    <script>
        function openCity(evt, cityName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }
            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(cityName).style.display = "block";
            evt.currentTarget.className += " active";
        }
    </script>
    @stop